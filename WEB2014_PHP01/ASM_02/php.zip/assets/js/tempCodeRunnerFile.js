import menProducts from "./view-product";

console.log(menProducts);