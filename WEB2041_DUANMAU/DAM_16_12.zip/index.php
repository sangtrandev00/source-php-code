<?php
ob_start();
header("location: ./site/index.php");