<div class="row">
    <div class="col-6">
        <form action="" method="post" class="p-5 ">
            <h1 class="h3 mb-3 fw-normal">Đổi mật khẩu</h1>

            <!-- <div class="form-floating mt-2">
                <input type="email" class="form-control" id="floatingInput" placeholder="name@example.com">
                <label for="floatingInput">Tên đăng nhập</label>
            </div> -->

            <div class="form-floating mt-2">
                <input name="newpass" type="password" class="form-control" required id="floatingPass1"
                    placeholder="Mật khẩu mới">
                <label for="floatingPass1">Mật khẩu mới</label>
            </div>
            <div class="form-floating mt-2">
                <input name="renewpass" type="password" class="form-control" required id="floatingPass1"
                    placeholder="Mật lại mật khẩu mới">
                <label for="floatingPass1">Mật lại mật khẩu mới</label>
            </div>

            <input name="updatepassbtn" class="w-100 btn btn -lg btn-primary mt-2" type="submit"
                value="Cập nhật mật khẩu">
            <p class="mt-5 mb-3 text-muted">&copy; 2017–2021</p>
        </form>
    </div>
</div>