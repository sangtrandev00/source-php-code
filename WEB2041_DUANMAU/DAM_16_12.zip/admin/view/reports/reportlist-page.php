<div class="report-list p-3">
    <h3 class="fs-3">Danh sách các thống kê</h3>
    <ul class="list-group shadow">
        <li class="list-group-item"><a href="./index.php?act=reportbycate">Thông kê hàng hóa theo từng loại </a></li>
        <li class="list-group-item"><a href="">Thông kê hàng hóa theo từng sản phẩm </a></li>
        <li class="list-group-item"><a href="">Thông kê bình luận theo từng sản phẩm</a></li>
        <li class="list-group-item"><a href="">Thông kê hàng hóa theo số người xem </a></li>
        <li class="list-group-item"><a href="">Thông kê hàng hóa theo đơn đặt hàng </a></li>
        <!-- <li class="list-group-item">And a fifth one</li> -->
    </ul>
</div>